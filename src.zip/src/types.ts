export interface ImageData {
	src: string;
	'data-hi-res?': string | null;
	'data-4x?': string | null;
}