import './App.css'
import { Grid } from "./components/Grid/Grid.tsx";
import { IMAGES } from "./constants.ts";

function App() {

  return (
    <Grid items={IMAGES}  />
  )
}

export default App
