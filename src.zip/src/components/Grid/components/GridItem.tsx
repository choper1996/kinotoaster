import React from 'react';
import type { ImageData } from "../../../types"

interface GridItemProps {
	data: ImageData;
	/** alt для доступности */
	alt?: string;
	/** колбэк клика, если нужно */
	onClick?: (data: ImageData) => void;
}

export const GridItem: React.FC<GridItemProps> = ({ data, alt = '', onClick }) => {
	const handleClick = () => onClick?.(data);

	return (
		<div
			className="grid-item"
			onClick={handleClick}
			role={onClick ? 'button' : undefined}
			tabIndex={onClick ? 0 : undefined}
		>
			<img
				className="grid-item__img"
				src={data['data-hi-res'] || data.src}
				srcSet={`
          ${data.src} 1x,
          ${data['data-hi-res']} 2x,
          ${data['data-4x']} 4x
        `}
				alt={alt}
				loading="lazy"
				decoding="async"
				data-hi-res={data['data-hi-res']}
				data-4x={data['data-4x']}
			/>
		</div>
	);
};