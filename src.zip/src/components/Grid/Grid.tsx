import React from 'react';

import { GridItem } from './components/GridItem';
import type { ImageData } from '../../types';

interface GridProps {
	items: ImageData[];
	/** минимальная ширина карточки в rem, по умолчанию 12.5rem = 200px */
	minItemWidth?: number;
	/** отступ между карточками в rem */
	gap?: number;
	onItemClick?: (data: ImageData) => void;
}

export const Grid: React.FC<GridProps> = ({
	items,
	minItemWidth = 12.5,
	gap = 1,
	onItemClick
}) => {
	return (
		<div
			className="grid"
			style={
				{
					'--grid-min-width': `${minItemWidth}rem`,
					'--grid-gap': `${gap}rem`,
				} as React.CSSProperties
			}
		>
			{items.map((item, i) => (
				<GridItem key={`${item.src}-${i}`} data={item} onClick={onItemClick} />
			))}
		</div>
	);
};